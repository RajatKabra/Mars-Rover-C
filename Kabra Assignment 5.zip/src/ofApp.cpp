
//--------------------------------------------------------------
//
//  CS235 - User Interface Design - Kevin M. Smith
//
//  Assignment 5 -  Mars HiRise Project - startup scene
// 
//  This is an openFrameworks 3D scene that includes an EasyCam
//  and example 3D geometry which I have reconstructed from Mars
//  HiRis photographs taken the Mars Reconnaisance Orbiter
//
//  You will use this source file (and include file) as a starting point
//  to implement assignment 5  (Parts I and II)
//
//  Please do not modify any of the keymappings.  I would like 
//  the input interface to be the same for each student's 
//  work.  Please also add your name/date below.

//  Please document/comment all of your work !
//  Have Fun !!
//
//  Student Name:   < Rajat Kabra >
//  Date: <11/08/2017>


#include "ofApp.h"
#include "math.h"



//--------------------------------------------------------------
// setup scene, lighting, state and load geometry
//
void ofApp::setup(){

	bWireframe = false;
	bDisplayPoints = false;
	bAltKeyDown = false;
	bCtrlKeyDown = false;
	bPointSelected = false;
	ofSetWindowShape(1024, 768);
	cam.setDistance(10);
	cam.setNearClip(.1);
	cam.setFov(65.5);   // approx equivalent to 28mm in 35mm format
	ofSetVerticalSync(true);
	cam.disableMouseInput();
	ofEnableSmoothing();
	ofEnableDepthTest();

	// setup rudimentary lighting 
	//
	initLightingAndMaterials();

	// load model (but do not scale)
	//
	mars.loadModel("mars-low-v2.obj");
	mesh = mars.getMesh(0);
	mars.setScaleNormalization(false);

}

//--------------------------------------------------------------
// incrementally update scene (animation)
//
void ofApp::update(){
	if (bMoveCameraForward && !bCtrlKeyDown) moveCamera(CamMoveForward, .05);
	else if (bMoveCameraBackward && !bCtrlKeyDown) moveCamera(CamMoveBackward, .05);

	else if (bRotateCameraLeft) rotateCamera(-1.0);   // rotate left/right
	else if (bRotateCameraRight) rotateCamera(1.0); 
	else if (bMoveCameraForward && bCtrlKeyDown) rotateCamera(-1.0);  // rotate up/down
	else if (bMoveCameraBackward && bCtrlKeyDown) rotateCamera(1.0);
	if (tel == true) telep();
	if (bTeleport==true) teleportCamera();
	vel += acceleration;
	vel *= 0.1;
	acceleration *= 0.99;
	// here we are defining the vector that contains the direction
	// in which the car should move, that is defined by the z-axis of the car and the velocity
	auto velVector = cam.getZAxis() * -vel;
	cam.move(velVector);
}

//--------------------------------------------------------------
void ofApp::draw(){

//	ofBackgroundGradient(ofColor(20), ofColor(0));   // pick your own backgroujnd
	ofBackground(ofColor::black);

	cam.begin();
	ofPushMatrix();
	if (bWireframe) {                    // wireframe mode  (include axis)
		ofDisableLighting();
		ofSetColor(ofColor::slateGray);
		mars.drawWireframe();
		drawAxis();
	}
	else {
		ofEnableLighting();              // shaded mode
		mars.drawFaces();
	}

	if (bDisplayPoints) {                // display points as an option    
		glPointSize(3);
		ofSetColor(ofColor::green);
		mars.drawVertices();
	}

	// highlight selected point (draw sphere around selected point)
	//
	if (bPointSelected) {
		ofSetColor(ofColor::blue);
		ofDrawSphere(selectedPoint, .1);
	}

	ofPopMatrix();
	cam.end();
}

// Draw an XYZ axis in RGB at world (0,0,0) for reference.
//
void ofApp::drawAxis() { 

	ofPushMatrix();
	ofSetColor(ofColor(255, 0, 0));
	ofDrawLine(ofPoint(0, 0, 0), ofPoint(1, 0, 0));
	ofSetColor(ofColor(0, 255, 0));
	ofDrawLine(ofPoint(0, 0, 0), ofPoint(0, 1, 0));
	ofSetColor(ofColor(0, 0, 255));
	ofDrawLine(ofPoint(0, 0, 0), ofPoint(0, 0, 1));
	ofPopMatrix();
}

void ofApp::steer(float dir) {
	cam.rotate(dir, 0, 1, 0); 
}

void ofApp::keyPressed(int key) {

	switch (key) {
	case 'C':
	case 'c':
		if (cam.getMouseInputEnabled()) cam.disableMouseInput();
		else cam.enableMouseInput();
		break;
	case 'F':
	case 'f':
		ofToggleFullscreen();
		break;
	case 'H':
	case 'h':
		break;
	case 'r':
		cam.reset();
		break;
	case 's':
		savePicture();
		break;
	case 't':
		setCameraTarget();
		break;
	case 'u':
		break;
	case 'v':
		togglePointsDisplay();
		break;
	case 'V':
		break;
	case 'w':
		toggleWireframeMode();
		break;
	case OF_KEY_ALT:
		cam.enableMouseInput();
		bAltKeyDown = true;
		break;
	case OF_KEY_CONTROL:
		bCtrlKeyDown = true;
		break;
	case OF_KEY_SHIFT:
		break;
	case OF_KEY_DEL:
		break;
	case OF_KEY_LEFT:
		steer(+1);
		break;
	case OF_KEY_RIGHT:
		steer(-1);
		break;
	case OF_KEY_UP:
		bMoveCameraForward = true;
		acc();
		break;
	case OF_KEY_DOWN:
		bMoveCameraBackward = true;
		back();
		break;
	case OF_KEY_F1:
		cam.reset();
		nextpoint.x = 0;
		nextpoint.y = 0;
		nextpoint.z = 0;
		teleportStartPoint = cam.getPosition();		
		bTeleport = true;
		xdegrees = 90;
		totaldis = teleportStartPoint.distance(selectedPoint);
		teledes = nextpoint.distance(selectedPoint);
		//teleportCamera();
		break;
	}
}

void ofApp::acc1() {
	cout << "F1";
	bPointSelected = false;
	int n = mesh.getNumVertices();
	float nearestDistance = 0;
	ofVec3f nearestVertex;
	int nearestIndex = 0;
	float distance;
	ofVec2f mouse(mouseX, mouseY);
	for (int i = 0; i < n; i++) {
		ofVec3f cur = cam.worldToScreen(mesh.getVertex(i));
		distance = cur.distance(mouse);
		if (distance<36000)
			if (i == 0 || distance < nearestDistance) {
				nearestDistance = distance;
				nearestVertex = cur;
				nearestIndex = i;
				bPointSelected = true;
			}
	}
	//selectedPoint = nearestVertex;
	selectedPoint = mesh.getVertex(nearestIndex);
	
	v = selectedPoint - cam.getPosition();
	v=v.normalize();
	//v *= 3;
	//v.z = v.z*.5;
	
	//cam.setTarget(selectedPoint);
	//cam.lookAt(selectedPoint);
	//ofSetColor(255, 255, 0, 10);
	//ofDrawSphere(selectedPoint, 50);
}

void ofApp::toggleWireframeMode() {
	bWireframe = !bWireframe;
}

void ofApp::acc() {
	acceleration += 0.1;
}
void ofApp::back() {
	acceleration -= 0.1;
}
void ofApp::togglePointsDisplay() {
	bDisplayPoints = !bDisplayPoints;
}

void ofApp::keyReleased(int key) {
	switch (key) {

	case OF_KEY_ALT:
		cam.disableMouseInput();
		bAltKeyDown = false;
		break;
	case OF_KEY_CONTROL:
		bCtrlKeyDown = false;
		break;
	case OF_KEY_SHIFT:
		break;
	case OF_KEY_LEFT:
		bRotateCameraLeft = false;
		break;
	case OF_KEY_RIGHT:
		bRotateCameraRight = false;
		break;
	case OF_KEY_UP:
		bMoveCameraForward = false;
		break;
	case OF_KEY_DOWN:
		bMoveCameraBackward = false;
		break;
	case OF_KEY_F1:
		//tel = false;
		//bTeleport = false;
		break;
	}
}



//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {

	if (bAltKeyDown == false && tel==false) doPointSelection(x,y);
}

//
//  Select Target Point on Terrain
//
void ofApp::doPointSelection(int x, int y) {
	bPointSelected = false;
	int n = mesh.getNumVertices();
	float nearestDistance = 0;
	ofVec3f nearestVertex;
	int nearestIndex = 0;
	float distance;
	ofVec2f mouse(mouseX, mouseY);
	for (int i = 0; i < n; i++) {
		ofVec3f cur = cam.worldToScreen(mesh.getVertex(i));
		distance = cur.distance(mouse);
		if(distance<36000)
		if (i == 0 || distance < nearestDistance) {
			nearestDistance = distance;
			nearestVertex = cur;
			nearestIndex = i;
			bPointSelected = TRUE;
		}
	}
	//selectedPoint = nearestVertex;
	selectedPoint = mesh.getVertex(nearestIndex);
	v = cam.getGlobalPosition() - selectedPoint;
	ofVec3f c = cam.getPosition();
	float d = c.z - selectedPoint.z;
	//dis = d;
	halfdis = d / 2;
	//teledes = 40;
	//v = v.normalize();
	/*ofSetColor(ofColor::gray);
	ofDrawLine(nearestVertex, mouse);

	ofNoFill();
	ofSetColor(ofColor::yellow);
	ofSetLineWidth(2);
	ofDrawCircle(nearestVertex, 4);
	ofSetLineWidth(1);

	ofVec2f offset(10, -10);
	ofDrawBitmapStringHighlight(ofToString(nearestIndex), mouse + offset);*/
}

// Set the camera to use the selected point as it's new target
//  
void ofApp::setCameraTarget() {
	cam.setTarget(selectedPoint);
}

// Animate camera by moving it to the selected points (using update())
//
void ofApp::moveCamera(CamMoveDirection dir, float step) {
	
}

// Rotate Camera Left/Right
//
void ofApp::rotateCamera(float step) {
}


//  "Teleport" Camera to Selected Target
// 

/*
void ofApp::teleportCamera() {
	
//	ofSetColor(ofColor::blue);
//	ofDrawSphere(selectedPoint, .1);
	//cam.setTarget(selectedPoint);
	ofVec3f c = cam.getPosition();
	float d = c.z - selectedPoint.z;
	if(d>2)
	{
	bMoveCameraForward = true;
	
		
		c = cam.getPosition();
		
		d = c.z - selectedPoint.z;
		
		cam.setPosition(cam.getPosition() + (v*0.1));
		cout << "\n" << d;
	}

	cout << "\n dis : "<<d<<endl;
	

}*/

void ofApp::teleportCamera()
{
	cam.setTarget(selectedPoint);
	teledes = nextpoint.distance(selectedPoint);
	if (teledes >= (totaldis / 2))
	{
		nextpoint.x = (teleportStartPoint.x - (v.x / (100 * abs(sin((xdegrees*3.14159 / 180))))));
		nextpoint.y = (teleportStartPoint.y - (v.y / (100 * abs(sin((xdegrees*3.14159 / 180))))));
		nextpoint.z = (teleportStartPoint.z - (v.z / (100 * abs(sin((xdegrees*3.14159 / 180))))));
		xdegrees = xdegrees - 1;
	}
	else if (teledes < (totaldis / 2) && teledes>0.5)
	{
		xdegrees = xdegrees + 1;
		nextpoint.x = (teleportStartPoint.x - (v.x / (250 * abs(sin((xdegrees*3.14159 / 180))))));
		nextpoint.y = (teleportStartPoint.y - (v.y / (250 * abs(sin((xdegrees*3.14159 / 180))))));
		nextpoint.z = (teleportStartPoint.z - (v.z / (250 * abs(sin((xdegrees*3.14159 / 180))))));
	}
	else
	{
		bTeleport = false;
		xdegrees = 0;
	}

	cam.setGlobalPosition(nextpoint);
	teleportStartPoint.x = nextpoint.x;
	teleportStartPoint.y = nextpoint.y;
	teleportStartPoint.z = nextpoint.z;
}
void ofApp::telep()
{

}
//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}

//--------------------------------------------------------------
// setup basic ambient lighting in GL  (for now, enable just 1 light)
//
void ofApp::initLightingAndMaterials() {

	static float ambient[] =
	{ .5f, .5f, .5, 1.0f };
	static float diffuse[] =
	{ 1.0f, 1.0f, 1.0f, 1.0f };

	static float position[] =
	{5.0, 5.0, 5.0, 0.0 };

	static float lmodel_ambient[] =
	{ 1.0f, 1.0f, 1.0f, 1.0f };

	static float lmodel_twoside[] =
	{ GL_TRUE };


	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT0, GL_POSITION, position);

	glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT1, GL_POSITION, position);


	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
	glLightModelfv(GL_LIGHT_MODEL_TWO_SIDE, lmodel_twoside);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
//	glEnable(GL_LIGHT1);
	glShadeModel(GL_SMOOTH);
} 

void ofApp::savePicture() {
	ofImage picture;
	picture.grabScreen(0, 0, ofGetWidth(), ofGetHeight());
	picture.save("screenshot.png");
	cout << "picture saved" << endl;
}
